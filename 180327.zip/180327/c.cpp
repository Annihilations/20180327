#include <bits/stdc++.h>
using namespace std;

typedef long long LL;

int n, dep[55];
LL sg;
char sign[55];
vector<int> adj[55];

void dfs(int x) {
	for (int i = 0; i < adj[x].size(); ++i) {
		int y = adj[x][i];
		dfs(y);
		dep[x] = max(dep[x], dep[y] + 1);
	}
	if (sign[x] == 'W')
		sg ^= 1LL << dep[x];
}

int main() {
	scanf("%d", &n);
	for (int i = 2; i <= n; ++i) {
		int x;
		scanf("%d", &x);
		adj[x].push_back(i);
	}
	scanf("%s", sign + 1);
	dfs(1);
	puts(sg ? "Alice" : "BillXu2000");
}
