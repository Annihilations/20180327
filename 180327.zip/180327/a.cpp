#include <bits/stdc++.h>
using namespace std;
typedef long long LL;

int n, m, mod, tot;
int f[6010][6010], x[4005], y[4005];

inline LL qpow(LL e, LL x, int m) {
	LL ret = 1;
	for (; x; x >>= 1, (e *= e) %= m)
		if (x & 1) (ret *= e) %= m;
	return ret;
}

inline int lagrange() {
	int sum = 1, ans = 0;
	for (int i = 1; i <= tot; ++i)
		sum = (LL)sum * (m - x[i] + mod) % mod;
	for (int i = 1; i <= tot; ++i) {
		int tmp = (m - x[i] + mod) % mod;
		for (int j = 1; j <= tot; ++j)
			if (i != j) tmp = (LL)tmp * (x[i] - x[j] + mod) % mod;
		ans = (ans + (LL)sum * qpow(tmp, mod - 2, mod) % mod * y[i]) % mod;
	}
	return ans;
}

inline int solve() {
	int ans = lagrange();
	for (int i = 2; i <= n; ++i)
		ans = (LL)ans * i % mod;
	return ans;
}

int main() {
	scanf("%d%d%d", &m, &n, &mod);
	f[0][0] = 1;
	for (int i = 1; i <= n * 3 + 3; ++i) {
		f[i][0] = 1;
		for (int j = 1; j <= n + 3; ++j)
			f[i][j] = (f[i - 1][j] + (LL)i * f[i - 1][j - 1] % mod) % mod;
	}
	for (int i = 1; tot <= n * 2; ++i)
		if (f[i][n] && i != m) {
			x[++tot] = i;
			y[tot] = f[i][n];
		}
//	for (int i = 1; i <= tot; ++i)
//		cerr << x[i] << " " << y[i] << "\n";
	printf("%d\n", solve());
}
