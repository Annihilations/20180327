#include <bits/stdc++.h>
using namespace std;
typedef long long LL;

struct P {int d[2];} ps[100010];
struct Q {int op, l, r;} qs[100010];
int n, m, plen, der, root, a[100010];
LL s[100010], ans = 0;
map<pair<int, int>, bool> ext;
struct node {
	int L[2], R[2], lch, rch;
	LL tag, mintag, sum, minsum;
	P p;
} t[100010];

inline bool cmp(const P &x, const P &y) {
	return x.d[der] < y.d[der];
}

inline void update_range(int x) {
	int lch = t[x].lch, rch = t[x].rch;
	for (int i = 0; i < 2; ++i) {
		if (lch) {
			t[x].L[i] = min(t[x].L[i], t[lch].L[i]);
			t[x].R[i] = max(t[x].R[i], t[lch].R[i]);
		}
		if (rch) {
			t[x].L[i] = min(t[x].L[i], t[rch].L[i]);
			t[x].R[i] = max(t[x].R[i], t[rch].R[i]);
		}
	}
}

int build(int l, int r, int d) {
	der = d;
	int mid = (l + r) >> 1;
	nth_element(ps + l, ps + mid, ps + r + 1, cmp);
	t[mid].p = ps[mid];
	t[mid].L[0] = t[mid].R[0] = ps[mid].d[0];
	t[mid].L[1] = t[mid].R[1] = ps[mid].d[1];
	if (l < mid) t[mid].lch = build(l, mid - 1, d ^ 1);
	if (mid < r) t[mid].rch = build(mid + 1, r, d ^ 1);
	update_range(mid);
	return mid;
}

inline bool check_in(int now, int l1, int r1, int l2, int r2) {
	return l1 <= t[now].L[0] && t[now].R[0] <= r1
		&& l2 <= t[now].L[1] && t[now].R[1] <= r2;
}
inline bool check_in(P p, int l1, int r1, int l2, int r2) {
	return l1 <= p.d[0] && p.d[0] <= r1
		&& l2 <= p.d[1] && p.d[1] <= r2;
}

inline void pushdown(int now) {
	t[now].minsum = min(t[now].minsum, t[now].sum + t[now].mintag);
	t[now].sum += t[now].tag;
	int lch = t[now].lch, rch = t[now].rch;
	if (lch) {
		t[lch].mintag = min(t[lch].mintag, t[lch].tag + t[now].mintag);
		t[lch].tag += t[now].tag;
	}
	if (rch) {
		t[rch].mintag = min(t[rch].mintag, t[rch].tag + t[now].mintag);
		t[rch].tag += t[now].tag;
	}
	t[now].tag = t[now].mintag = 0;
}

void change(int now, int l1, int r1, int l2, int r2, int d) {
	if (t[now].L[0] > r1 || t[now].R[0] < l1) return;
	if (t[now].L[1] > r2 || t[now].R[1] < l2) return;
	if (check_in(now, l1, r1, l2, r2)) {
		t[now].tag += d;
		t[now].mintag = min(t[now].mintag, t[now].tag);
		return;
	}
	pushdown(now);
	if (check_in(t[now].p, l1, r1, l2, r2)) {
		t[now].sum += d;
		t[now].minsum = min(t[now].minsum, t[now].sum);
	}
	if (t[now].lch) change(t[now].lch, l1, r1, l2, r2, d);
	if (t[now].rch) change(t[now].rch, l1, r1, l2, r2, d);
}

LL qry(int now, int l, int r) {
	if (!now) return 0;
	if (t[now].L[0] > l || t[now].R[0] < l) return 0;
	if (t[now].L[1] > r || t[now].R[1] < r) return 0;
	pushdown(now);
	if (t[now].p.d[0] == l && t[now].p.d[1] == r)
		return t[now].minsum;
	return qry(t[now].lch, l, r) + qry(t[now].rch, l, r);
}

int main() {
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", a + i);
		s[i] = s[i - 1] + a[i];
	}
	for (int i = 1; i <= m; ++i) {
		scanf("%d%d%d", &qs[i].op, &qs[i].l, &qs[i].r);
		if (qs[i].op == 2) {
			if (ext[make_pair(qs[i].l, qs[i].r)]) continue;
			++plen;
			ps[plen].d[0] = qs[i].l;
			ps[plen].d[1] = qs[i].r;
			ext[make_pair(qs[i].l, qs[i].r)] = true;
		}
	}
	root = build(1, plen, 0);
	for (int i = 1; i <= m; ++i)
		if (qs[i].op == 1) {
			int d = qs[i].r - a[qs[i].l];
			a[qs[i].l] = qs[i].r;
			change(root, 1, qs[i].l, qs[i].l, n, d);
		} else {
			ans = s[qs[i].r] - s[qs[i].l - 1] + qry(root, qs[i].l, qs[i].r);
			printf("%lld\n", ans);
		}
}
